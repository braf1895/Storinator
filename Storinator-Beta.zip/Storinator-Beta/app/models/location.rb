class Location < ApplicationRecord
  has_many :item
end
