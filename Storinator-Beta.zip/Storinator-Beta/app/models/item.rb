class Item < ApplicationRecord
  #belongs_to :location
end
